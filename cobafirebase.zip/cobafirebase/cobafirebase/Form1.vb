﻿Imports System.Net.Http
Imports System.Net
Imports Newtonsoft.Json
Imports System.ComponentModel
Imports System.IO
Imports System.Text

Public Class Form1
    Public axCZKEM1 As New zkemkeeper.CZKEM
    Private Const BaseAdress As String = "https://sincere-quasar-257103.firebaseio.com/Absen/.json?auth={0}"
    Private Const Token As String = "7CklnhMGDLdHWsQ9osn3SlizXsKjEsUirkBsCDea"
    Private ReadOnly _firebaseUri As String = String.Format(BaseAdress, Token)
    Private ReadOnly _sourceabsen As BindingSource = New BindingSource
    Private ReadOnly _sourceuser As BindingSource = New BindingSource
    Private ReadOnly _sourcetoken As BindingSource = New BindingSource


    Private Shared Async Function HttpRestAsync(uri As String, Optional data As String = Nothing) As Task(Of String)
        Dim httpClient = New HttpClient()
        Dim response = If(String.IsNullOrEmpty(data), Await httpClient.GetAsync(uri),
            Await httpClient.PostAsync(uri, New StringContent(data)))
        response.EnsureSuccessStatusCode()
        Return Await response.Content.ReadAsStringAsync()
    End Function

    Private Async Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Button1.Enabled = False
        Button1.Enabled = Await LoadDataAbsen()
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tableAbsen.DataSource = _sourceabsen
        tblUser.DataSource = _sourceuser
        tblDevice.DataSource = _sourcetoken
        Dim timeValue As Integer = Now.ToString("HHmm")
        If timeValue >= My.Settings.jmmasuk And timeValue <= My.Settings.jmpulang Then
            rbMasuk.Checked = True
        Else
            rbKeluar.Checked = True
        End If
    End Sub


    Private Async Function LoadDataAbsen() As Task(Of Boolean)


        Try
            Dim result = Await HttpRestAsync(_firebaseUri)
            If String.IsNullOrEmpty(result) Then
                Return True
            End If
            Try
                ListBox1.Items.Add("[" + DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss") + "] Menampilkan data absen.")
                _sourceabsen.DataSource = JsonConvert.DeserializeObject(Of Dictionary(Of String, Absen))(result).Select(Function(s)
                                                                                                                            s.Value.Id = s.Key
                                                                                                                            Return s.Value
                                                                                                                        End Function).ToList()
            Catch ex As Exception
                MessageBox.Show(String.Format("Error: {0}", ex.Message))
            End Try
            txtDatabase.Text = "Terhubung"
            txtDatabase.ForeColor = Color.Green
            txtJMLAbsen.Text = tableAbsen.Rows.Count.ToString()
            txtAbsen.Text = tableAbsen.Rows.Count.ToString()
        Catch ex As Exception
            MessageBox.Show("Gagal Terhubung dengan database, Pastikan anda terhubung dengan internet ", "Error")
            txtDatabase.Text = "Tidak terhubung"
            txtDatabase.ForeColor = Color.Red
        End Try


        Return True
    End Function
    Private NotInheritable Class Absen
        <JsonIgnore>
        Public Property Id As String
        <JsonProperty("kode")>
        Public Property Kode As String
        <JsonProperty("nama")>
        Public Property Nama As String
        <JsonProperty("tanggal")>
        Public Property Tanggal As String
        <JsonProperty("waktu")>
        Public Property Waktu As String
        <JsonProperty("ket")>
        Public Property Keterangan As String
        <JsonProperty("timestamp")>
        Public Property Timestamp As String
        <JsonProperty("urutkan")>
        Public Property TokenId As String
    End Class

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        txtJam.Text = DateTime.Now.ToString("HH:mm:ss")
    End Sub

    Private Sub Detik3_Tick(sender As Object, e As EventArgs) Handles Detik5.Tick

        'cekInternet()
    End Sub

#Region "Communication"
    Private bIsConnected = False 'the boolean value identifies whether the device is connected
    Private iMachineNumber As Integer 'the serial number of the device.After connecting the device ,this value will be changed.

    Private Sub btnConnect_Click(sender As Object, e As EventArgs) Handles btnConnect.Click
        If txtIP.Text.Trim() = "" Or txtPort.Text.Trim() = "" Then
            MsgBox("IP dan Port harus di isi", MsgBoxStyle.Exclamation, "Gagal")
            Return
        End If
        Dim idwErrorCode As Integer
        Cursor = Cursors.WaitCursor
        If btnConnect.Text = "Putuskan" Then
            axCZKEM1.Disconnect()

            RemoveHandler axCZKEM1.OnAttTransactionEx, AddressOf AxCZKEM1_OnAttTransactionEx
            bIsConnected = False
            btnConnect.Text = "Hubungkan"
            lblState.Text = "Terputus"
            txtStsMesin2.Text = "Mesin tidak siap."
            txtStsMesin2.ForeColor = Color.Red
            Cursor = Cursors.Default
            Return
        End If

        bIsConnected = axCZKEM1.Connect_Net(txtIP.Text.Trim(), Convert.ToInt32(txtPort.Text.Trim()))
        If bIsConnected = True Then
            btnConnect.Text = "Putuskan"
            btnConnect.Refresh()
            lblState.Text = "Terhubung"
            txtStsMesin2.Text = "Mesin siap."
            txtStsMesin2.ForeColor = Color.Green
            iMachineNumber = 1 'In fact,when you are using the tcp/ip communication,this parameter will be ignored,that is any integer will all right.Here we use 1.

            If axCZKEM1.RegEvent(iMachineNumber, 65535) = True Then 'Here you can register the realtime events that you want to be triggered(the parameters 65535 means registering all)

                AddHandler axCZKEM1.OnAttTransactionEx, AddressOf AxCZKEM1_OnAttTransactionEx
            End If
            If txtStatus.Text = "Jaringan tersedia." And txtDatabase.Text = "Terhubung" Then
                txtMainStatus.Text = "Sudah Siap"
                txtMainStatus.ForeColor = Color.Green
            End If
        Else
            axCZKEM1.GetLastError(idwErrorCode)
            MsgBox("Unable to connect the device,ErrorCode=" & idwErrorCode, MsgBoxStyle.Exclamation, "Error")
        End If
        Cursor = Cursors.Default


    End Sub
#End Region
#Region "RealTime Events"
    'When you place your finger on sensor of the device,this event will be triggered

    'If your fingerprint(or your card) passes the verification,this event will be triggered
    Private Sub AxCZKEM1_OnAttTransactionEx(ByVal sEnrollNumber As String, ByVal iIsInValid As Integer, ByVal iAttState As Integer, ByVal iVerifyMethod As Integer,
                      ByVal iYear As Integer, ByVal iMonth As Integer, ByVal iDay As Integer, ByVal iHour As Integer, ByVal iMinute As Integer, ByVal iSecond As Integer, ByVal iWorkCode As Integer)
        Dim metod As String
        If iVerifyMethod.ToString() = "1" Then
            metod = "Jari"
        Else
            metod = "Password"
        End If
        ListBox1.Items.Add("[" + DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss") + "] Transaksi diterima - UserID: " & sEnrollNumber & " - NIS: " & tblUser.Rows(sEnrollNumber - 1).Cells(1).Value & " - Nama: " & tblUser.Rows(sEnrollNumber - 1).Cells(2).Value & " - Kelas: " & tblUser.Rows(sEnrollNumber - 1).Cells(4).Value & " - Metode absen: " & metod)
        createAbsen(sEnrollNumber)
        carikode(sEnrollNumber, DateTime.Now.ToString("HH:mm"))
    End Sub


    Private Sub Form1_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Dim sb As New System.Text.StringBuilder()

        For Each o As Object In ListBox1.Items
            sb.AppendLine(o)
        Next

        System.IO.File.WriteAllText(Application.StartupPath & "\log-" & DateTime.Now.ToString("ddMMyyyyHHmmss") & ".txt", sb.ToString())
        If MessageBox.Show(" Apakah anda yakin ingin keluar ?", "Keluar", MessageBoxButtons.YesNo) <> DialogResult.Yes Then
            e.Cancel = True
        End If
    End Sub

#End Region
#Region "Data User"
    Private NotInheritable Class User
        <JsonIgnore>
        Public Property Id As String
        <JsonProperty("nis")>
        Public Property NIS As String
        <JsonProperty("nama")>
        Public Property Nama As String
        <JsonProperty("jk")>
        Public Property JenisKelamin As String
        <JsonProperty("kelas")>
        Public Property Kelas As String
        <JsonProperty("rombel")>
        Public Property Rombel As String
        <JsonProperty("tgllhr")>
        Public Property TglLahir As String
        <JsonProperty("tmplhr")>
        Public Property TmpLahir As String
    End Class
    Private Async Function LoadDataUser() As Task(Of Boolean)
        Const BaseAdress As String = "https://sincere-quasar-257103.firebaseio.com/Siswa/.json?auth={0}"
        Const Token As String = "7CklnhMGDLdHWsQ9osn3SlizXsKjEsUirkBsCDea"
        Dim _firebaseUri2 As String = String.Format(BaseAdress, Token)

        Try
            Dim result = Await HttpRestAsync(_firebaseUri2)
            If String.IsNullOrEmpty(result) Then
                Return True
            End If
            Try
                ListBox1.Items.Add("[" + DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss") + "] Menampilkan data user.")
                _sourceuser.DataSource = JsonConvert.DeserializeObject(Of Dictionary(Of String, User))(result).Select(Function(s)
                                                                                                                          s.Value.Id = s.Key
                                                                                                                          Return s.Value
                                                                                                                      End Function).ToList()
            Catch ex As Exception
                MessageBox.Show(String.Format("Error: {0}", ex.Message))
            End Try
            txtDatabase.Text = "Terhubung"
            txtDatabase.ForeColor = Color.Green
            Label8.Text = tblUser.Rows.Count.ToString()
            txtUsercount.Text = tblUser.Rows.Count.ToString()
        Catch ex As Exception
            MessageBox.Show(ex.ToString, "Error")
            txtDatabase.Text = "Tidak terhubung"
            txtDatabase.ForeColor = Color.Red
        End Try


        Return True
    End Function

    Private Async Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Button4.Enabled = False
        Button4.Enabled = Await LoadDataUser()
    End Sub
    Private Async Function createAbsen(id As String) As Task(Of Boolean)
        Dim kett, kettcode, nama, tgl, jam As String
        Const BaseAdress As String = "https://sincere-quasar-257103.firebaseio.com/Absen/.json?auth={0}"
        Const Token As String = "7CklnhMGDLdHWsQ9osn3SlizXsKjEsUirkBsCDea"
        Dim _firebaseUri2 As String = String.Format(BaseAdress, Token)
        nama = tblUser.Rows(id - 1).Cells(2).Value
        tgl = DateTime.Now.ToString("dd/MM/yyyy")
        jam = DateTime.Now.ToString("HH:mm")
        If rbMasuk.Checked = True Then
            kett = "Masuk"
            kettcode = "1"
        ElseIf rbKeluar.Checked = True Then
            kett = "Keluar"
            kettcode = "2"
        End If
        Dim x As Integer
        x = tblUser.Rows(id - 1).Cells(1).Value

        Try
            Dim Absen = New Absen With {
           .Kode = x,
           .Nama = nama,
           .Tanggal = tgl,
           .Waktu = jam,
           .Keterangan = kett,
           .Timestamp = DateTime.Now.ToString("yyyyMMddHHmmss"),
           .TokenId = x & DateTime.Now.ToString("yyyyMMdd") & kettcode
       }
            Await HttpRestAsync(_firebaseUri2, JsonConvert.SerializeObject(Absen))
            ListBox1.Items.Add("[" + DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss") + "] Data tersimpan")

        Catch ex As Exception
            MessageBox.Show(String.Format("Error: {0}", ex.Message))
        End Try
        Await LoadDataAbsen()

    End Function


    Private Sub ListBox1_TabIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.TabIndexChanged
        ListBox1.TopIndex = ListBox1.Items.Count - 1
    End Sub


    Public Async Function IsInternetConnected() As Task(Of Boolean)
        Try
            Using client = New WebClient()
                Using stream = client.OpenRead("http://www.google.com")
                    Return True
                End Using
            End Using
        Catch
        End Try
        Return False
    End Function
    Private Async Sub cekInternet()
        Dim hasil As Boolean = Await IsInternetConnected()
        If hasil = True Then
            txtStatus.Text = "Jaringan tersedia."
            txtStatus.ForeColor = Color.Green
        Else
            txtStatus.Text = "Jaringan tidak tersedia"
            txtStatus.ForeColor = Color.Red
            txtMainStatus.Text = "Belum Siap"
            txtMainStatus.ForeColor = Color.Red
        End If
    End Sub



    Private Async Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' cekInternet()
        LoadDataAbsen()
        LoadDataUser()
        LoadDataToken()
        Dim hasil As Boolean = Await IsInternetConnected()
        If hasil = True Then
            txtStatus.Text = "Jaringan tersedia."
            txtStatus.ForeColor = Color.Green
        Else
            txtStatus.Text = "Jaringan tidak tersedia"
            txtStatus.ForeColor = Color.Red
            txtMainStatus.Text = "Belum Siap"
            txtMainStatus.ForeColor = Color.Red
        End If
        If txtStsMesin2.Text = "Mesin siap." Then
            If hasil = True Then
                txtMainStatus.Text = "Sudah Siap"
                txtMainStatus.ForeColor = Color.Green
            End If
        Else
            txtStsMesin2.Text = "Silahkan hubungkan mesin."
            txtStsMesin2.ForeColor = Color.Red
        End If
    End Sub


#End Region
#Region "datadevice"
    Private NotInheritable Class Device
        <JsonIgnore>
        Public Property Id As String
        <JsonProperty("kode")>
        Public Property Kode As String
        <JsonProperty("token")>
        Public Property Token As String
    End Class
    Private Async Function LoadDataToken() As Task(Of Boolean)
        Const BaseAdress As String = "https://sincere-quasar-257103.firebaseio.com/Token/.json?auth={0}"
        Const Token As String = "7CklnhMGDLdHWsQ9osn3SlizXsKjEsUirkBsCDea"
        Dim _firebaseUri2 As String = String.Format(BaseAdress, Token)

        Try
            Dim result = Await HttpRestAsync(_firebaseUri2)
            If String.IsNullOrEmpty(result) Then
                Return True
            End If
            Try
                ListBox1.Items.Add("[" + DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss") + "] Menampilkan data device.")
                _sourcetoken.DataSource = JsonConvert.DeserializeObject(Of Dictionary(Of String, Device))(result).Select(Function(s)
                                                                                                                             s.Value.Id = s.Key
                                                                                                                             Return s.Value
                                                                                                                         End Function).ToList()
            Catch ex As Exception
                MessageBox.Show(String.Format("Error: {0}", ex.Message))
            End Try
            Label1.Text = tblDevice.Rows.Count.ToString()
        Catch ex As Exception
            MessageBox.Show(ex.ToString, "Error")
        End Try


        Return True
    End Function

    Private Async Function Button3_ClickAsync(sender As Object, e As EventArgs) As Task Handles Button3.Click
        Button3.Enabled = False
        Button3.Enabled = Await LoadDataToken()
    End Function
    Function FindValue(ByRef dgv As DataGridView, ByVal metric_key As Object) As String
        For Each row As DataGridViewRow In dgv.Rows
            If row.Cells.Item("Kode").Value = metric_key Then
                Return row.Index.ToString()
            End If
        Next
        Return ""
    End Function

#End Region
#Region "request notif"
    Public Function carikode(ByRef ind As String, ByRef waktu As String)
        Dim kode = tblUser.Rows(ind - 1).Cells(1).Value
        Dim nama = tblUser.Rows(ind - 1).Cells(2).Value
        Dim kett As String
        If rbMasuk.Checked = True Then
            kett = "Masuk"
        ElseIf rbKeluar.Checked = True Then
            kett = "Keluar"
        End If
        Dim dgv As DataGridView = tblDevice
        Dim hasil As String = FindValue(dgv, kode)
        Dim token As String = tblDevice.Rows(hasil).Cells(2).Value
        Dim judul = "Absen " & kett
        Dim isi = "Ananda " & nama & " telah " & kett & " lingkungan sekolah pada pukul " & waktu
        judul = judul.Replace(" ", "%20")
        isi = isi.Replace(" ", "%20")
        Dim balasan = Sendnotif(token, judul, isi)
        ListBox1.Items.Add("[" + DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss") + "] Status notifikasi : " + balasan)

    End Function
    Public Function Sendnotif(ByVal token As String, ByVal judul As String, ByVal isi As String) As String
        Try
            Dim url As String = My.Settings.URL
            Dim request As System.Net.WebRequest = System.Net.WebRequest.Create(url)
            request.Method = "POST"
            Dim postData = "id=" & token & "&tittle=" & judul & "&body=" & isi
            Dim byteArray As Byte() = Encoding.UTF8.GetBytes(postData)
            request.ContentType = "application/x-www-form-urlencoded"
            request.ContentLength = byteArray.Length
            Dim dataStream As Stream = request.GetRequestStream()
            dataStream.Write(byteArray, 0, byteArray.Length)
            dataStream.Close()
            Dim response As WebResponse = request.GetResponse()
            dataStream = response.GetResponseStream()
            Dim reader As New StreamReader(dataStream)
            Dim responseFromServer As String = reader.ReadToEnd()
            reader.Close()
            dataStream.Close()
            response.Close()
            Dim scr = "success"
            Dim FirstCharacter As Integer = responseFromServer.IndexOf(scr)
            Dim hsl As String
            Dim hasil = GetChar(responseFromServer, FirstCharacter + 10)
            If hasil = "1" Then
                hsl = "SUCCESS"
            Else
                hsl = "FAILURE"
            End If
            Return (hsl)
        Catch ex As Exception
            Dim error1 As String = ErrorToString()
            If error1 = "Invalid URI: The format of the URI could not be determined." Then
                MsgBox("ERROR! Must have HTTP:// before the URL.")
            Else
                MsgBox(error1)
            End If
            Return ("ERROR")
        End Try
    End Function

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        setting.ShowDialog()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim judul As String = TextBox1.Text
        Dim isi As String = TextBox2.Text
        Dim token As String = TextBox3.Text
        Dim state As String = Sendnotif(token, judul, isi)
        ListBox1.Items.Add("[" + DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss") + "] Status pengiriman notifikasi : " + state)
        MsgBox(state)
    End Sub

    Private Sub tblDevice_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles tblDevice.CellContentClick
        Dim value As Object = tblDevice.Rows(e.RowIndex).Cells(2).Value
        TextBox3.Text = value
    End Sub


#End Region
End Class


