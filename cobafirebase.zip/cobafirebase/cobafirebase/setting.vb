﻿Public Class setting

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        savesetting()
    End Sub

    Private Sub setting_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        loadsetting()
    End Sub
    Public Sub loadsetting()
        TextBox1.Text = My.Settings.URL
        TextBox2.Text = My.Settings.jmmasuk
        TextBox3.Text = My.Settings.jmpulang
    End Sub
    Public Sub savesetting()
        My.Settings.URL = TextBox1.Text
        My.Settings.jmmasuk = TextBox2.Text
        My.Settings.jmpulang = TextBox3.Text
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        savesetting()
        Me.Close()
    End Sub
End Class